#
# 24の棋譜の中から平手対局を抽出する
#

import os
import glob
import numpy as np
import sys
import subprocess
import shutil

idir = "kifu"
odir = "hirate"
args = sys.argv
argc = len(args)

if argc > 1:
    idir = args[1] + "/*.kif"
if argc > 2:
    odir = args[2]

ilst = glob.glob(idir)  # idirに入ってる棋譜を対象とする

hirate = []
selcnt = 0

for fn in ilst:
    fl    = open(fn, "r", encoding="shift_jis")
    lines = fl.readlines()
    fl.close()
    # 50手以上指していて、ちゃんと投了している棋譜を抽出する
    if "平手" in lines[2]:
        wkstr = lines[-1].split(" ")
        if wkstr[0].isdecimal():
            tesu = int(wkstr[0]) - 1
            if (tesu > 50) and (wkstr[1].strip() == "投了"):
                hirate.append(fn)
                selcnt += 1

# 抽出したファイルをodirフォルダにコピーする
for fn in hirate:
    shutil.copy(fn,odir)
print("{0}件中、{1}件を抽出しました。".format(len(ilst),selcnt))
