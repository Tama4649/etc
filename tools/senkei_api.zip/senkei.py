#
# CSA形式の棋譜から戦型、囲いを分類する
#

import shogi     as sg
import shogi.CSA as csa
import shogi.KIF as kif

senkei = [
    "角換わり", "矢倉", "横歩取り", "相掛かり", "袖飛車", "右四間飛車", "中飛車",
    "ゴキゲン中飛車","四間飛車", "三間飛車", "向かい飛車"
]

# 囲い一覧
# 2つ目のTrue、Falseは、振ってないことを条件とするか否かのスイッチ
# 3つ目以降は駒位置（USI形式）＋駒種類（USI形式）で表す

bkakoi = [
    ["矢倉", False, "7hG", "7gS"],
    ["雁木", True, "7hG", "6gS"],
    ["美濃", False, "3hS", "4hK"],
    ["美濃", False, "3hS", "4iK"],
    ["美濃", False, "3hS", "3iK"],
    ["美濃", False, "3hS", "2hK"],
    ["左美濃", False, "7hS", "6hK"],
    ["左美濃", False, "7hS", "6iK"],
    ["左美濃", False, "7hS", "7iK"],
    ["左美濃", False, "7hS", "8hK"],
    ["銀冠", False, "2gS", "3hG", "4hK"],
    ["銀冠", False, "2gS", "3hG", "4iK"],
    ["銀冠", False, "2gS", "3hG", "3iK"],
    ["銀冠", False, "2gS", "3hG", "2hK"],
    ["右銀冠", False, "8gS", "7hG", "6hK"],
    ["右銀冠", False, "8gS", "7hG", "6iK"],
    ["右銀冠", False, "8gS", "7hG", "7iK"],
    ["右銀冠", False, "8gS", "7hG", "8hK"],
    ["舟囲い", False, "5hG", "9iG", "4fP", "7fP"],
    ["天守閣", False, "8gK", "8hB", "7hS", "6iG"],
    ["金無双", False, "5hG", "4hG", "3hK", "2hS"],
    ["居飛穴", False, "9hL", "9iK"],
    ["振り穴", False, "1hL", "1iK"],
    ["ミレニアム", False, "8hS", "8iK"],
    ["右ミレニアム", False, "2hS", "2iK"],
    ["elmo", False, "7iG", "6hS", "7hK"],
    ["右elmo", False, "3iG", "4hS", "3hK"]
]

wkakoi = [
    ["矢倉", False, "3bg", "3cs"],
    ["雁木", True, "3bg", "4cs"],
    ["美濃", False, "7bd", "6bk"],
    ["美濃", False, "7bs", "6ak"],
    ["美濃", False, "7bs", "7ak"],
    ["美濃", False, "7bs", "8bk"],
    ["左美濃", False, "3bs", "4bk"],
    ["左美濃", False, "3bs", "4ak"],
    ["左美濃", False, "3bs", "3ak"],
    ["左美濃", False, "3bs", "2bk"],
    ["銀冠", False, "8cs", "7bg", "6bk"],
    ["銀冠", False, "8cs", "7bg", "6ak"],
    ["銀冠", False, "8cs", "7bg", "7ak"],
    ["銀冠", False, "8cs", "7bg", "8bk"],
    ["右銀冠", False, "2cs", "3bg", "4bk"],
    ["右銀冠", False, "2cs", "3bg", "4ak"],
    ["右銀冠", False, "2cs", "3bg", "3ak"],
    ["右銀冠", False, "2cs", "3bg", "2bk"],
    ["舟囲い", False, "5bg", "4ag", "5dp", "3dp"],
    ["天守閣", False, "2ck", "2bb", "3bs", "4ag"],
    ["金無双", False, "5bg", "6bg", "7bk", "8bs"],
    ["居飛穴", False, "1bl", "1ak"],
    ["振り穴", False, "9bl", "9ak"],
    ["ミレニアム", False, "2bs", "2ak"],
    ["右ミレニアム", False, "8bs", "8ak"],
    ["elmo", False, "3ag", "4bs", "3bk"],
    ["右elmo", False, "7ag", "6bs", "7bk"]
]

# python-shogiのKIFオフジェクトを渡し、戦型判別文字列を返す

def ans_senkei(kif):

    tagstr = ""
    brd    = sg.Board()
    bs     = [False, False, False, False, False, False, False, False, False, False, False]
    ws     = [False, False, False, False, False, False, False, False, False, False, False]
    bk     = "その他"
    wk     = "その他"
    bssw   = False
    wssw   = False
    bksw   = False
    wksw   = False
    bst    = 1
    wst    = 1
    bkt    = 1
    wkt    = 1

    for i, moves in enumerate(kif['moves']):

        bpos = moves[:2]                            # 動かす前の座標
        apos = moves[2:4]                           # 動かした後の座標
        bssw = False
        wssw = False

        if True in bs[1:]:                          # 戦型が決まっていたら
            bssw = True
        if True in ws[1:]:                          # 戦型が決まっていたら
            wssw = True
        if not bk == "その他":                      # 囲いが決まっていたら
            bksw = True
        if not wk == "その他":                      # 囲いが決まっていたら
            wksw = True

        if i > 29:                                  # 30手目までで判断
            break

        if bpos[0].isdecimal():                     # 駒移動なら
            bp = str(brd.piece_at(sg.SQUARES[sg.SQUARE_NAMES.index(bpos)]))
            ap = str(brd.piece_at(sg.SQUARES[sg.SQUARE_NAMES.index(apos)]))
            if not bssw and not wssw:
                if bp == "B" and ap == "b":
                    bs[0] = True                    # 角換わり
                    ws[0] = True                    # 角換わり
                    bst   = i + 1
                    wst   = i + 1
            if not bssw and not wssw:
                if bp == "b" and ap == "B":
                    bs[0] = True                    # 角換わり
                    ws[0] = True                    # 角換わり
                    bst   = i + 1
                    wst   = i + 1
            if not bssw and not wssw:
                if moves == "2d3d":
                    if bp == "R" and ap == "p" and not bs[0]:
                        bs[2] = True                # 横歩取り
                        ws[2] = True                # 横歩取り
                        bssw  = True
                        wssw  = True
                        bst   = i + 1
                        wst   = i + 1
            if not bssw and not wssw:
                if moves == "8f7f":
                    if bp == "r" and ap == "p" and not bs[0]:
                        bs[2] = True                # 横歩取り
                        ws[2] = True                # 横歩取り
                        bssw  = True
                        wssw  = True
                        bst   = i + 1
                        wst   = i + 1
            if not bssw and not wssw:
                if moves == "2e2d" and kif['moves'][i + 1] == "2c2d" and kif['moves'][i + 2] == "2h2d" and not bs[0]:
                    bs[3] = True                    # 相掛かり
                    ws[3] = True                    # 相掛かり
                    bssw  = True
                    wssw  = True
                    bst   = i + 1
                    wst   = i + 1
            if not bssw and not wssw:
                if moves == "8e8f" and kif['moves'][i + 1] == "8g8f" and kif['moves'][i + 2] == "8b8f" and not bs[0]:
                    bs[3] = True                    # 相掛かり
                    ws[3] = True                    # 相掛かり
                    bssw  = True
                    wssw  = True
                    bst   = i + 1
                    wst   = i + 1
            if brd.turn == 0:                       # 先手番
                p1 = str(brd.piece_at(sg.SQUARES[sg.SQUARE_NAMES.index("2g")])) # ２七
                if not bssw:
                    if moves == "2h3h":
                        bs[4] = True                # 袖飛車
                        bssw  = True
                        bst   = i + 1
                if not bssw:
                    if moves == "2h4h":
                        bs[5] = True                # 右四間飛車
                        bssw  = True
                        bst   = i + 1
                if not bssw:
                    if moves == "2h5h" and p1 == "P":
                        p2 = str(brd.piece_at(sg.SQUARES[sg.SQUARE_NAMES.index("5g")])) # ５七
                        p3 = str(brd.piece_at(sg.SQUARES[sg.SQUARE_NAMES.index("7g")])) # ７七
                        if p2 == "P" or p3 == "P":  # ５筋か７筋の歩を突いていなかったら
                            bs[6] = True            # 中飛車
                        else:
                            bs[7] = True            # ゴキゲン中飛車
                        bssw  = True
                        bst   = i + 1
                if not bssw:
                    if moves == "2h6h" and p1 == "P":
                        bs[8] = True                # 四間飛車
                        bssw  = True
                        bst   = i + 1
                if not bssw:
                    if moves == "2h7h" and p1 == "P":
                        bs[9] = True                # 三間飛車
                        bssw  = True
                        bst   = i + 1
                if not bssw:
                    if moves == "2h8h" and p1 == "P":
                        bs[10] = True               # 向かい飛車
                        bssw   = True
                        bst    = i + 1
            else:                                   # 後手番
                p1 = str(brd.piece_at(sg.SQUARES[sg.SQUARE_NAMES.index("8c")])) # ８三
                if not wssw:
                    if moves == "8b7b":
                        ws[4] = True                # 袖飛車
                        wssw  = True
                        wst   = i + 1
                if not wssw:
                    if moves == "8b6b":
                        ws[5] = True                # 右四間飛車
                        wssw  = True
                        wst   = i + 1
                if not wssw:
                    if moves == "8b5b" and p1 == "p":
                        p2 = str(brd.piece_at(sg.SQUARES[sg.SQUARE_NAMES.index("5c")])) # ５三
                        p3 = str(brd.piece_at(sg.SQUARES[sg.SQUARE_NAMES.index("3c")])) # ３三
                        if p2 == "p" or p3 == "p":  # ５筋か３筋の歩を突いていなかったら
                            ws[6] = True            # 中飛車
                        else:
                            ws[7] = True            # ゴキゲン中飛車
                        wssw  = True
                        wst   = i + 1
                if not wssw:
                    if moves == "8b4b" and p1 == "p":
                        ws[8] = True                # 四間飛車
                        wssw  = True
                        wst   = i + 1
                if not wssw:
                    if moves == "8b3b" and p1 == "p":
                        ws[9] = True                # 三間飛車
                        wssw  = True
                        wst   = i + 1
                if not wssw:
                    if moves == "8b2b" and p1 == "p":
                        ws[10] = True               # 向かい飛車
                        wssw   = True
                        wst    = i + 1

        brd.push(sg.Move.from_usi(moves))           # 1手指す

        if brd.turn == 1:                           # 先手番（指した後なので反転して判別）
            if not bksw:
                for kakoi in bkakoi:
                    wsw = True
                    for wpos in kakoi[2:]:
                        wp = str(brd.piece_at(sg.SQUARES[sg.SQUARE_NAMES.index(wpos[:2])]))
                        if wp != wpos[2]:
                            wsw = False
                    if wsw:                         # 囲いの条件に合致したら
                        if kakoi[1]:                # 振ってない条件が必要
                            if not (True in bs[4:]):
                                bk  = kakoi[0]
                                bkt = i + 1
                                if bk == "矢倉" and not bssw:
                                    bs[1] = True
                        else:
                            bk  = kakoi[0]
                            bkt = i + 1
                            if bk == "矢倉" and not bssw:   # 現状、ここにはこない
                                bs[1] = True
        else:                                       # 後手番
            if not wksw:
                for kakoi in wkakoi:
                    wsw = True
                    for wpos in kakoi[2:]:
                        wp = str(brd.piece_at(sg.SQUARES[sg.SQUARE_NAMES.index(wpos[:2])]))
                        if wp != wpos[2]:
                            wsw = False
                    if wsw:                         # 囲いの条件に合致したら
                        if kakoi[1]:                # 振ってない条件が必要
                            if not (True in ws[4:]):
                                wk  = kakoi[0]
                                wkt = i + 1
                                if wk == "矢倉" and not wssw:
                                    ws[1] = True
                        else:
                            wk  = kakoi[0]
                            wkt = i + 1
                            if wk == "矢倉" and not wssw:   # 現状、ここにはこない
                                ws[1] = True

    # 先手戦型
    esw = False
    if bs[0]:                                               # 角交換が入っている
        if not bssw and not wssw:                           # 他に戦型が決まっていない
            tagstr += senkei[0] + ":" + str(bst) + ","      # 角換わり固定
            esw     = True
        else:
            for i, wsw in enumerate(bs[1:]):
                if wsw:
                    if i > 4:                               # 振り飛車なら
                        tagstr += "角交換" + senkei[i + 1] + ":" + str(bst) + ","
                    else:
                        tagstr += senkei[i + 1] + ":" + str(bst) + ","
                    esw = True
                    break
    else:
        for i, wsw in enumerate(bs[1:]):
            if wsw:
                tagstr += senkei[i + 1] + ":" + str(bst) + ","
                esw     = True
                break
    if not esw:
        tagstr += "力戦:" + str(bst) + ","

    # 後手戦型
    esw = False
    if ws[0]:                                               # 角交換が入っている
        if not bssw and not wssw:                           # 他に戦型が決まっていない
            tagstr += senkei[0] + ":" + str(wst) + ","      # 角換わり固定
            esw     = True
        else:
            for i, wsw in enumerate(ws[1:]):
                if wsw:
                    if i > 4:                               # 振り飛車なら
                        tagstr += "角交換" + senkei[i + 1] + ":" + str(wst) + ","
                    else:
                        tagstr += senkei[i + 1] + ":" + str(wst) + ","
                    esw = True
                    break
    else:
        for i, wsw in enumerate(ws[1:]):
            if wsw:
                tagstr += senkei[i + 1] + ":" + str(wst) + ","
                esw     = True
                break
    if not esw:
        tagstr += "力戦:" + str(wst) + ","

    # 先手囲い
    tagstr += bk + ":" + str(bkt) + ","

    # 後手囲い
    tagstr += wk + ":" + str(wkt)

    tagstr2 = tagstr.replace("角交換向かい飛車", "ダイレクト向かい飛車")
    return tagstr2


# CSA形式の棋譜ファイルの内容を渡し、戦型判別文字列を返す

def tag_str(csastr):

    kif = csa.Parser.parse_str(csastr)[0]
    return ans_senkei(kif)

# CSA形式の棋譜を読み込み、戦型判定文字列を返す

def tag_file(fname):

    with open(fname, "r", encoding="utf-8") as in_f:
        csastr = in_f.read()
    return tag_str(csastr)

# KIF形式の棋譜ファイルの内容を渡し、戦型判別文字列を返す

def tag_str_kif(kifstr):

    kif2 = kif.Parser.parse_str(kifstr)[0]
    return ans_senkei(kif2)

# KIF形式の棋譜を読み込み、戦型判定文字列を返す

def tag_file_kif(fname):

    with open(fname, "r", encoding="shift_jis") as in_f:
        kifstr = in_f.read()
    return tag_str_kif(kifstr)
