<?php

$cmd  = "python3 senkei_api.py ";
$ifn  = "select/work.csa";
$cmd .= $ifn;

exec($cmd, $out);
print "$out[0]\n";		// 配列で返ってくるようなので、0番目だけ使用します

?>
