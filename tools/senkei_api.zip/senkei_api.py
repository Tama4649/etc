#
# CSA形式の棋譜から戦型を分類し、タグファイルを出力する
#

import sys, glob, senkei

args = sys.argv
argc = len(args)
ifn  = ""

if argc < 2:                    # パラメータが指定されていなかったら
    ifn = "csa/work.csa"
else:
    ifn = args[1]

print(senkei.tag_file(ifn))     # 戦型タグを付加する
