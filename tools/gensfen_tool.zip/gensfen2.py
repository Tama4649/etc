import io, sys, time
import ayane.Ayane as ayane
import shogi as sg
import random as rnd

# 2エンジンの対局

# エンジン1、エンジン2による対局棋譜から教師局面ファイル（テキスト型）を生成する。
# できあがったファイルをやねうら王のconvert_binコマンドで.binファイルに変換して
# 使用する。
# 引き分けの教師は、エンジン2のほうの教師局面ファイルに出力するものとする。

# 各エンジンの設定はengine_option.txtにて設定することを前提としている。
# （このスクリプトでは行わない）
# 対局時の評価値は10000(-10000)でカンストとし、mate発見時も10000として、これが現れた
# 時点で対局を打ち切る。
# エンジン1を振り飛車側とし、対局結果、振り飛車側が勝ちまた引き分けだったらファイルを
# 出力する。

# エンジンクラス
class Engine:
    def __init__(self):
        # メンバ
        self.Eng = ayane.UsiEngine()    # UsiEngineオブジェクト
        self.EN   = ""                  # エンジン名
        self.Id  = None                 # 0,1の2つ
        self.clear()

    def clear(self):
        # Idはクリアしちゃダメよ！
        self.Exe = False                # 実行中フラグ
        self.Pos = ""                   # 指し手
        self.Res = ""                   # Cmdに対するResult
        self.BM  = ""                   # Cmdに対するbestmove
        self.PD  = ""                   # Cmdに対するponder
        self.CP  = 0                    # bestmoveの評価値

    def think(self, pos):
        self.Eng.usi_position(self.Pos)
        self.Exe = True
        self.Eng.usi_go_and_wait_bestmove(pos)
        self.Exe = False
        self.Res = self.Eng.think_result.to_string()
        self.BM  = self.Eng.think_result.bestmove
        self.PD  = self.Eng.think_result.ponder
        self.CP  = self.Eng.think_result.pvs[0].eval

# 集計クラス
class Shukei:
    def __init__(self):
        self.BWin = 0                   # 先手番勝ち数
        self.WWin = 0                   # 後手番勝ち数
        self.BLos = 0                   # 先手番負け数
        self.WLos = 0                   # 後手番負け数
        self.BDrw = 0                   # 先手番引分数
        self.WDrw = 0                   # 後手番引分数

# 初期化
def Init():
    global pd, cpos, ef, en, pres, depth, nodes

    cpos = ""

    for i in range(2):
        pd.append(Engine())
        pd[i].Id = i
        pd[i].EN = en[i]
        pd[i].debug_print = True
        pres.append(Shukei())

    # エンジンオプション自体は、基本的には"engine_options.txt"で設定する。(やねうら王のdocs/を読むべし)
    # 特定のエンジンオプションをさらに上書きで設定できる
    #pd[i].Eng.set_engine_options({"Hash":"128","Threads":"1","MultiPV": str(MP),"BookFile":"no_book"})

    # エンジンに接続
    # 通常の思考エンジンであるものとする。
    for i, wpd in enumerate(pd):
        wpd.Eng.connect(ef[i])
        wpd.Eng.send_command("DepthLimit " + depth)
        wpd.Eng.send_command("NodesLimit " + nodes)
 
# クリア処理（エンジンを止めて変数クリアしてreadyok状態にする）
def AllClear():
    global pd

    for wpd in pd:
        if wpd.Exe:
            wpd.Eng.usi_stop()
            wpd.Eng.wait_bestmove()
        wpd.Eng.send_command("usinewgame")
        wpd.Eng.send_command("isready")
        wpd.clear()

# 終了処理
def Close():
    global pd

    for wpd in pd:
        wpd.Eng.disconnect()
    return

# メイン処理
args  = sys.argv
argc  = len(args)
ef    = [ "exe1/JK18-t", "exe2/JK18-t" ]
en    = [ "test25", "BURNING_BRIDGES" ]
gsfen = "sfens_bak/taya36.sfen"
depth = "24"
nodes = "30000000"
lc    = 100
byo   = "30000"
ofn1  = "sfens/e1win.sfen"
ofn2  = "sfens/e2win.sfen"
lfn   = "log/result.log"
tu    = [ 0, 1 ]

if argc > 1:
    depth = str(args[1])
if argc > 2:
    nodes = str(args[2])
if argc > 3:
    en[0] = args[3]
if argc > 4:
    ef[0] = args[4]
if argc > 5:
    en[1] = args[5]
if argc > 6:
    ef[1] = args[6]
if argc > 7:
    gsfen = args[7]
if argc > 8:
    lc = int(args[8])
if argc > 9:
    byo = str(args[9])

go = "byoyomi " + byo

# 棋譜情報
sfens  = []     # 局面SFEN
moves  = []     # 局面指し手
scores = []     # 局面評価値
tesus  = []     # 局面手数
tebans = []     # 局面手番
pd     = []     # エンジン用オブジェクト
pres   = []     # 集計用オブジェクト

# 互角局面ファイルを読み込んでランダムシャッフルする
gsfens = []
with open(gsfen, "r") as inf:
    gsfens = inf.readlines()
rnd.seed()
rsfens = rnd.sample(gsfens, len(gsfens))

# エンジン初期化
Init()

# 指定回数、対局を行わせる
rc = 0
for c in range(lc):
    print("{0:5d}局目 {1}：".format(c + 1, en), end="", flush=True)
    AllClear()
    sfens.clear()
    moves.clear()
    scores.clear()
    tesus.clear()
    tebans.clear()
    cPos = rsfens[rc].strip()
    wpv  = cPos.split(" ")
    tesu = len(wpv) - 1
    if (len(wpv) - 2) % 2 == 0:
        teban = 0
    else:
        teban = 1
    sfen   = ""
    cMoves = ""
    bMoves = ""
    isDraw = False
    winp   = ""
    brd    = sg.Board()
    for i, pv in enumerate(wpv):
        if i > 1:
            brd.push_usi(pv)
    while True:
        wpd = pd[tu[teban]]
        if cMoves != "":
            cPos += " " + cMoves
        sfen = brd.sfen()
        wpd.Pos = cPos
        wpd.think(go)
        if wpd.BM == "resign":
            break
        wkCP = wpd.CP
        if wkCP is None:
            wkCP = 0
        if "mate" in wpd.Res:
            gomi, wkStrA = wpd.Res.split(" mate ")
            wkStrB = wkStrA.split(" ")
            wkCP = -10001 if int(wkStrB[0]) < 0 else 10001
        if wkCP > 10000:
            wkCP = 10000    # 10000でカンスト
        elif wkCP < -10000:
            wkCP = -10000   # -10000でカンスト
        bMoves = cMoves
        cMoves = wpd.BM
        sfens.append(sfen)
        moves.append(cMoves)
        scores.append(wkCP)
        tesus.append(tesu)
        if teban == 0:
            tebans.append("b")
            teban = 1
        else:
            tebans.append("w")
            teban = 0
        if wkCP > 9999:
            break
        if wkCP < -9999:
            break
        brd.push_usi(cMoves)
        tesu += 1
        if tesu > 320:      # 手数が320を越えたら
            isDraw = True   # 引き分けとみなす
            break

    # 結果集計
    e1sw = False            # エンジン1出力
    e2sw = False            # エンジン2出力
    if isDraw:              # 引き分けなら
        print("引き分け", flush=True)
        e1sw = False
        e2sw = True         # エンジン2に教師出力
        if tu[0] == 0:      # 先手がエンジン1なら
            pres[0].BDrw += 1
            pres[1].WDrw += 1
        else:
            pres[1].BDrw += 1
            pres[0].WDrw += 1
    elif tebans[-1] == "b": # 最後が先手
        winp = "b"          # 先手の勝ち
        print("先手勝ち", flush=True)
    else:                   # 最後が後手
        winp = "w"          # 後手の勝ち
        print("後手勝ち", flush=True)
    if not isDraw:
        if winp == "b":     # 先手の勝ちの時
            if tu[0] == 0:  # 先手がエンジン1
                e1sw = True
                pres[0].BWin += 1
                pres[1].BLos += 1
            else:           # 先手がエンジン2
                e2sw = True
                pres[1].BWin += 1
                pres[0].BLos += 1
        else:               # 後手の勝ちの時
            if tu[1] == 0:  # 後手がエンジン1
                e1sw = True
                pres[0].WWin += 1
                pres[1].WLos += 1
            else:           # 後手がエンジン2
                e2sw = True
                pres[1].WWin += 1
                pres[0].WLos += 1

    # エンジン1と2で分けてファイル出力する
    if e1sw:                # エンジン1側出力対象なら
        #if not isDraw:
            #print("{}勝った！".format(pd[0].EN), flush=True)
        # 教師局面ファイルに書き出す
        with open(ofn1, "a") as fl:
            for ri, sfen in enumerate(reversed(sfens)):
                i = len(sfens) - ri
                if ri > 0:  # 10000の値は書き出さない
                    fl.write("sfen "  + sfens[i]       + "\n")
                    fl.write("move "  + moves[i]       + "\n")
                    fl.write("score " + str(scores[i]) + "\n")
                    fl.write("ply "   + str(tesus[i])  + "\n")
                    if isDraw:
                        fl.write("result 0\n")
                    elif winp == "b":   # 先手勝ちだったら
                        if tebans[i] == "b":
                            fl.write("result 1\n")
                        else:
                            fl.write("result -1\n")
                    else:               # 後手勝ちだったら
                        if tebans[i] == "w":
                            fl.write("result 1\n")
                        else:
                            fl.write("result -1\n")
                    fl.write("e\n")

    if e2sw:                # エンジン2側出力対象なら
        #if isDraw:
            #print("引き分け！", flush=True)
        #else:
            #print("{}勝った！".format(pd[1].EN), flush=True)
        # 教師局面ファイルに書き出す
        with open(ofn2, "a") as fl:
            for ri, sfen in enumerate(reversed(sfens)):
                i = len(sfens) - ri
                if ri > 0:  # 10000の値は書き出さない
                    fl.write("sfen "  + sfens[i]       + "\n")
                    fl.write("move "  + moves[i]       + "\n")
                    fl.write("score " + str(scores[i]) + "\n")
                    fl.write("ply "   + str(tesus[i])  + "\n")
                    if isDraw:
                        fl.write("result 0\n")
                    elif winp == "b":   # 先手勝ちだったら
                        if tebans[i] == "b":
                            fl.write("result 1\n")
                        else:
                            fl.write("result -1\n")
                    else:               # 後手勝ちだったら
                        if tebans[i] == "w":
                            fl.write("result 1\n")
                        else:
                            fl.write("result -1\n")
                    fl.write("e\n")

    tu[0], tu[1] = tu[1], tu[0]
    en[0], en[1] = en[1], en[0]

    rc += 1
    if rc == len(gsfens):
        rc = 0

Close()

print("")

with open(lfn, "a") as lf:
    for i, wen in enumerate(pres):
        lf.write("{}:".format(pd[i].EN) + "\n")
        lf.write("　先手勝ち:{0:3d} 後手勝ち:{1:3d}".format(wen.BWin, wen.WWin) + "\n")
        lf.write("　先手負け:{0:3d} 後手負け:{1:3d}".format(wen.BLos, wen.WLos) + "\n")
        lf.write("　先手引分:{0:3d} 後手引分:{1:3d}".format(wen.BDrw, wen.WDrw) + "\n")
        lf.write("　トータル:{0:3d}勝{1:3d}敗{2:3d}分".format(wen.BWin + wen.WWin, wen.BLos + wen.WLos, wen.BDrw + wen.WDrw) + "\n")
