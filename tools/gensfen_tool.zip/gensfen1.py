import io, sys, time
import random as rnd
import ayane.Ayane as ayane
import shogi as sg

# 1エンジンでの教師局面の生成

# 対局棋譜から教師局面ファイル（テキスト型）を生成する。
# できあがったファイルをやねうら王のconvert_binコマンドで.binファイルに変換して
# 使用する。
# エンジンの設定はengine_option.txtにて設定することを前提としている。
# （このスクリプトでは行わない）
# 対局時の評価値は10000(-10000)でカンストとし、mate発見時も10000として、これが現れた
# 時点で対局を打ち切る。
# 2021/1/23
# 互角局面ファイルを読み込み、そこからランダムに進めたところから開始するようにした。

# エンジンクラス
class Engine:
    def __init__(self):
        # メンバ
        self.Eng = ayane.UsiEngine()    # UsiEngineオブジェクト
        self.Id  = None                 # 0,1の2つ
        self.clear()

    def clear(self):
        # Idはクリアしちゃダメよ！
        self.Exe = False                # 実行中フラグ
        self.Pos = ""                   # 指し手
        self.Res = ""                   # Cmdに対するResult
        self.BM  = ""                   # Cmdに対するbestmove
        self.PD  = ""                   # Cmdに対するponder
        self.CP  = 0                    # bestmoveの評価値

    def think(self, pos):
        self.Eng.usi_position(self.Pos)
        self.Exe = True
        self.Eng.usi_go_and_wait_bestmove(pos)
        self.Exe = False
        self.Res = self.Eng.think_result.to_string()
        self.BM  = self.Eng.think_result.bestmove
        self.PD  = self.Eng.think_result.ponder
        self.CP  = self.Eng.think_result.pvs[0].eval

# 初期化
def Init():
    global pd, cpos, ef

    cpos = ""
    pd   = Engine()

    # デバッグ用にエンジンとのやりとり内容を標準出力に出力する。
    # usi.debug_print = True

    # エンジンオプション自体は、基本的には"engine_options.txt"で設定する。(やねうら王のdocs/を読むべし)
    # 特定のエンジンオプションをさらに上書きで設定できる
    #odr.Eng.set_engine_options({"Hash":"128","Threads":"1","MultiPV": str(MP),"BookFile":"no_book"})

    # エンジンに接続
    # 通常の思考エンジンであるものとする。
    pd.Eng.connect(ef)
 
# クリア処理（エンジンを止めて変数クリアしてreadyok状態にする）
def AllClear():
    global pd
    if pd.Exe:
        pd.Eng.usi_stop()
        pd.Eng.wait_bestmove()
    pd.Eng.send_command("usinewgame")
    pd.Eng.send_command("isready")
    pd.clear()

# 終了処理
def Close():
    global pd
    pd.Eng.disconnect()
    return

# メイン処理
args  = sys.argv
argc  = len(args)
gsfen = "sfens_bak/taya36.sfen"
lc    = 100000
byo   = "30000"
ofn   = "sfens/work.sfen"
ef    = "exe1/JK18-t"

if argc > 1:
    lc = int(args[1])
if argc > 2:
    byo = str(args[2])
if argc > 3:
    ef = args[3]
if argc > 4:
    gsfen = args[4]
if argc > 5:
    ofn = args[5]

go = "byoyomi " + byo

# 棋譜情報
sfens  = []     # 局面SFEN
moves  = []     # 局面指し手
scores = []     # 局面評価値
tesus  = []     # 局面手数
tebans = []     # 局面手番

# 互角局面ファイルを読み込んでランダムシャッフルする
gsfens = []
with open(gsfen, "r") as inf:
    gsfens = inf.readlines()
rnd.seed()
rsfens = rnd.sample(gsfens, len(gsfens))

# エンジン初期化
Init()

# 指定回数、対局を行わせる
rc = 0
for c in range(lc):
    print("{0:5d}局目：".format(c + 1), end="", flush=True)
    AllClear()
    sfens.clear()
    moves.clear()
    scores.clear()
    tesus.clear()
    tebans.clear()
    cPos = rsfens[rc].strip()
    wpv  = cPos.split(" ")
    tesu = len(wpv) - 1
    if (len(wpv) - 2) % 2 == 0:
        teban = 0
    else:
        teban = 1
    sfen   = ""
    cMoves = ""
    bMoves = ""
    isDraw = False
    winp   = ""
    brd    = sg.Board()
    for i, pv in enumerate(wpv):
        if i > 1:
            brd.push_usi(pv)
    while True:
        if cMoves != "":
            cPos += " " + cMoves
        sfen = brd.sfen()
        pd.Pos = cPos
        pd.think(go)
        if pd.BM == "resign":
            break
        wkCP = pd.CP
        if wkCP is None:
            wkCP = 0
        if "mate" in pd.Res:
            gomi, wkStrA = pd.Res.split(" mate ")
            wkStrB = wkStrA.split(" ")
            wkCP = -10001 if int(wkStrB[0]) < 0 else 10001
        if wkCP > 10000:
            wkCP = 10000    # 10000でカンスト
        elif wkCP < -10000:
            wkCP = -10000   # -10000でカンスト
        bMoves = cMoves
        cMoves = pd.BM
        sfens.append(sfen)
        moves.append(cMoves)
        scores.append(wkCP)
        tesus.append(tesu)
        if teban == 0:
            tebans.append("b")
            teban = 1
        else:
            tebans.append("w")
            teban = 0
        if wkCP > 9999:
            break
        if wkCP < -9999:
            break
        brd.push_usi(cMoves)
        tesu += 1
        if tesu > 320:      # 手数が320を越えたら
            isDraw = True   # 引き分けとみなす
            break

    if isDraw:
        print("引き分け", flush=True)
    elif tebans[-1] == "b": # 最後が先手
        winp = "b"          # 先手の勝ち
        print("先手勝ち", flush=True)
    else:                   # 最後が後手
        winp = "w"          # 後手の勝ち
        print("後手勝ち", flush=True)

    # 教師局面ファイルに書き出す
    with open(ofn, "a") as fl:
        for ri, sfen in enumerate(reversed(sfens)):
            i = len(sfens) - ri
            if ri > 0:      # 10000の値は書き出さない
                fl.write("sfen "  + sfens[i]       + "\n")
                fl.write("move "  + moves[i]       + "\n")
                fl.write("score " + str(scores[i]) + "\n")
                fl.write("ply "   + str(tesus[i])  + "\n")
                if isDraw:
                    fl.write("result 0\n")
                elif winp == "b":   # 先手勝ちだったら
                    if tebans[i] == "b":
                        fl.write("result 1\n")
                    else:
                        fl.write("result -1\n")
                else:               # 後手勝ちだったら
                    if tebans[i] == "w":
                        fl.write("result 1\n")
                    else:
                        fl.write("result -1\n")
                fl.write("e\n")

    rc += 1
    if rc == len(gsfens):
        rc = 0

Close()
