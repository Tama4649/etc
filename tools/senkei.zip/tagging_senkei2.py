#!/home/tama/.pyenv/shims/python3

#
# KIF形式の棋譜から戦型を分類し、タグファイルを出力する
#

import sys, glob, senkei

idir  = "kif/*.kif"
ofile = "senkei.csv"
args  = sys.argv
argc  = len(args)

if argc > 1:
    idir = args[1] + "/*.kif"
if argc > 2:
    ofile = args[2]

with open(ofile, "w", encoding="utf-8") as ofp:
    #ofp.write("先手戦型,後手戦型,先手囲い,後手囲い,ファイルパス\n")
    ilst = sorted(glob.glob(idir))          # idirに入っている棋譜を対象とする
    for ifile in ilst:
        tagstr = senkei.tag_file_kif(ifile) # 戦型タグを付加する
        ofp.write(tagstr + "," + ifile + "\n")
