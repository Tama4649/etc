#
# CSA形式の棋譜から戦型、囲いを分類する
#

import shogi     as sg
import shogi.CSA as csa
import shogi.KIF as kif

senkei = [
    "角換わり", "矢倉", "横歩取り", "相掛かり", "袖飛車", "右四間飛車", "中飛車",
    "四間飛車", "三間飛車", "向かい飛車"
]
kakoi  = [
    "矢倉", "雁木", "美濃", "穴熊", "ミレニアム", "elmo"
]

# python-shogiのKIFオフジェクトを渡し、戦型判別文字列を返す

def ans_senkei(kif):

    tagstr = ""
    brd    = sg.Board()
    bs     = [False, False, False, False, False, False, False, False, False, False]
    ws     = [False, False, False, False, False, False, False, False, False, False]
    bk     = [False, False, False, False, False, False]
    wk     = [False, False, False, False, False, False]
    bssw   = False
    wssw   = False
    bksw   = False
    wksw   = False

    for i, moves in enumerate(kif['moves']):

        bpos = moves[:2]                            # 動かす前の座標
        apos = moves[2:4]                           # 動かした後の座標
        bssw = False
        wssw = False

        if True in bs[1:]:                          # 戦型が決まっていたら
            bssw = True
        if True in ws[1:]:                          # 戦型が決まっていたら
            wssw = True
        if True in bk:                              # 囲いが決まっていたら
            bksw = True
        if True in wk:                              # 囲いが決まっていたら
            wksw = True

        if i > 29:                                  # 30手目までで判断
            break

        if bpos[0].isdecimal():                     # 駒移動なら
            bp = str(brd.piece_at(sg.SQUARES[sg.SQUARE_NAMES.index(bpos)]))
            ap = str(brd.piece_at(sg.SQUARES[sg.SQUARE_NAMES.index(apos)]))
            if not bssw and not wssw:
                if bp == "B" and ap == "b":
                    bs[0] = True                    # 角換わり
                    ws[0] = True                    # 角換わり
            if not bssw and not wssw:
                if bp == "b" and ap == "B":
                    bs[0] = True                    # 角換わり
                    ws[0] = True                    # 角換わり
            if not bssw and not wssw:
                if moves == "2d3d":
                    if bp == "R" and ap == "p" and not bs[0]:
                        bs[2] = True                # 横歩取り
                        ws[2] = True                # 横歩取り
                        bssw  = True
                        wssw  = True
            if not bssw and not wssw:
                if moves == "8f7f":
                    if bp == "r" and ap == "p" and not bs[0]:
                        bs[2] = True                # 横歩取り
                        ws[2] = True                # 横歩取り
                        bssw  = True
                        wssw  = True
            if not bssw and not wssw:
                if moves == "2e2d" and kif['moves'][i + 1] == "2c2d" and kif['moves'][i + 2] == "2h2d" and not bs[0]:
                    bs[3] = True                    # 相掛かり
                    ws[3] = True                    # 相掛かり
                    bssw  = True
                    wssw  = True
            if not bssw and not wssw:
                if moves == "8e8f" and kif['moves'][i + 1] == "8g8f" and kif['moves'][i + 2] == "8b8f" and not bs[0]:
                    bs[3] = True                    # 相掛かり
                    ws[3] = True                    # 相掛かり
                    bssw  = True
                    wssw  = True
            if brd.turn == 0:                       # 先手番
                p1 = str(brd.piece_at(sg.G2))       # ２七
                if not bssw:
                    if moves == "2h3h":
                        bs[4] = True                # 袖飛車
                        bssw  = True
                if not bssw:
                    if moves == "2h4h":
                        bs[5] = True                # 右四間飛車
                        bssw  = True
                if not bssw:
                    if moves == "2h5h" and p1 == "P":
                        bs[6] = True                # 中飛車
                        bssw  = True
                if not bssw:
                    if moves == "2h6h" and p1 == "P":
                        bs[7] = True                # 四間飛車
                        bssw  = True
                if not bssw:
                    if moves == "2h7h" and p1 == "P":
                        bs[8] = True                # 三間飛車
                        bssw  = True
                if not bssw:
                    if moves == "2h8h" and p1 == "P":
                        bs[9] = True                # 向かい飛車
                        bssw  = True
            else:                                   # 後手番
                p1 = str(brd.piece_at(sg.C8))       # ８四
                if not wssw:
                    if moves == "8b7b":
                        ws[4] = True                # 袖飛車
                        wssw  = True
                if not wssw:
                    if moves == "8b6b":
                        ws[5] = True                # 右四間飛車
                        wssw  = True
                if not wssw:
                    if moves == "8b5b" and p1 == "p":
                        ws[6] = True                # 中飛車
                        wssw  = True
                if not wssw:
                    if moves == "8b4b" and p1 == "p":
                        ws[7] = True                # 四間飛車
                        wssw  = True
                if not wssw:
                    if moves == "8b3b" and p1 == "p":
                        ws[8] = True                # 三間飛車
                        wssw  = True
                if not wssw:
                    if moves == "8b2b" and p1 == "p":
                        ws[9] = True                # 向かい飛車
                        wssw  = True

        brd.push(sg.Move.from_usi(moves))           # 1手指す

        if brd.turn == 1:                           # 先手番（指した後なので反転して判別）
            if not bksw:
                p1 = str(brd.piece_at(sg.H7))       # ７八
                p2 = str(brd.piece_at(sg.G7))       # ７七
                if not bs[0] and p1 == "G" and p2 == "S":
                    if not (True in bs[4:]):        # 振られてなければ
                        bk[0] = True                # 矢倉
                        bs[1] = True                # 矢倉
                        bksw  = True
            if not bksw:
                p1 = str(brd.piece_at(sg.H7))       # ７八
                p2 = str(brd.piece_at(sg.G6))       # ６七
                if p1 == "G" and p2 == "S":
                    if not (True in bs[4:]):        # 振られてなければ
                        bk[1] = True                # 雁木
                        bksw  = True
            if not bksw:
                p1 = str(brd.piece_at(sg.H3))       # ３八
                p2 = str(brd.piece_at(sg.H4))       # ４八
                p3 = str(brd.piece_at(sg.I4))       # ４九
                p4 = str(brd.piece_at(sg.I3))       # ３九
                p5 = str(brd.piece_at(sg.H2))       # ２八
                if p1 == "S" and p2 == "K":
                    bk[2] = True                    # 美濃
                    bksw  = True
                if p1 == "S" and p3 == "K":
                    bk[2] = True                    # 美濃
                    bksw  = True
                if p1 == "S" and p4 == "K":
                    bk[2] = True                    # 美濃
                    bksw  = True
                if p1 == "S" and p5 == "K":
                    bk[2] = True                    # 美濃
                    bksw  = True
            if not bksw:
                p1 = str(brd.piece_at(sg.H7))       # ７八
                p2 = str(brd.piece_at(sg.H6))       # ６八
                p3 = str(brd.piece_at(sg.I6))       # ６九
                p4 = str(brd.piece_at(sg.I7))       # ７九
                p5 = str(brd.piece_at(sg.H8))       # ８八
                if p1 == "S" and p2 == "K":
                    bk[2] = True                    # 左美濃
                    bksw  = True
                if p1 == "S" and p3 == "K":
                    bk[2] = True                    # 左美濃
                    bksw  = True
                if p1 == "S" and p4 == "K":
                    bk[2] = True                    # 左美濃
                    bksw  = True
                if p1 == "S" and p5 == "K":
                    bk[2] = True                    # 左美濃
                    bksw  = True
            if not bksw:
                p1 = str(brd.piece_at(sg.H9))       # ９八
                p2 = str(brd.piece_at(sg.I9))       # ９九
                if p1 == "L" and p2 == "K":
                    bk[3] = True                    # 穴熊
                    bksw  = True
            if not bksw:
                p1 = str(brd.piece_at(sg.H1))       # １八
                p2 = str(brd.piece_at(sg.I1))       # １九
                if p1 == "L" and p2 == "K":
                    bk[3] = True                    # 穴熊
                    bksw  = True
            if not bksw:
                p1 = str(brd.piece_at(sg.H8))       # ８八
                p2 = str(brd.piece_at(sg.I8))       # ８九
                if p1 == "S" and p2 == "K":
                    bk[4] = True                    # ミレニアム
                    bksw  = True
            if not bksw:
                p1 = str(brd.piece_at(sg.H2))       # ２八
                p2 = str(brd.piece_at(sg.I2))       # ２九
                if p1 == "S" and p2 == "K":
                    bk[4] = True                    # ミレニアム
                    bksw  = True
            if not bksw:
                p1 = str(brd.piece_at(sg.I7))       # ７九
                p2 = str(brd.piece_at(sg.H6))       # ６八
                p3 = str(brd.piece_at(sg.H7))       # ７八
                if p1 == "G" and p2 == "S" and p3 == "K":
                    bk[5] = True                    # elmo
                    bksw  = True
            if not bksw:
                p1 = str(brd.piece_at(sg.I3))       # ３九
                p2 = str(brd.piece_at(sg.H4))       # ４八
                p3 = str(brd.piece_at(sg.H3))       # ３八
                if p1 == "G" and p2 == "S" and p3 == "K":
                    bk[5] = True                    # elmo
                    bksw  = True
        else:                                       # 後手番
            if not wksw:
                p1 = str(brd.piece_at(sg.B3))
                p2 = str(brd.piece_at(sg.C3))
                if not ws[0] and p1 == "g" and p2 == "s":
                    if not (True in ws[4:]):        # 振られてなければ
                        wk[0] = True                # 矢倉
                        ws[1] = True                # 矢倉
                        wksw  = True
            if not wksw:
                p1 = str(brd.piece_at(sg.B3))
                p2 = str(brd.piece_at(sg.C4))
                if p1 == "g" and p2 == "s":
                    if not (True in ws[4:]):        # 振られてなければ
                        wk[1] = True                # 雁木
                        wksw  = True
            if not wksw:
                p1 = str(brd.piece_at(sg.B7))       # ７二
                p2 = str(brd.piece_at(sg.B6))       # ６二
                p3 = str(brd.piece_at(sg.A6))       # ６一
                p4 = str(brd.piece_at(sg.A7))       # ７一
                p5 = str(brd.piece_at(sg.B8))       # ８二
                if p1 == "s" and p2 == "k":
                    wk[2] = True                    # 美濃
                    wksw  = True
                if p1 == "s" and p3 == "k":
                    wk[2] = True                    # 美濃
                    wksw  = True
                if p1 == "s" and p4 == "k":
                    wk[2] = True                    # 美濃
                    wksw  = True
                if p1 == "s" and p5 == "k":
                    wk[2] = True                    # 美濃
                    wksw  = True
            if not wksw:
                p1 = str(brd.piece_at(sg.B3))       # ３二
                p2 = str(brd.piece_at(sg.B4))       # ４二
                p3 = str(brd.piece_at(sg.A4))       # ４一
                p4 = str(brd.piece_at(sg.A3))       # ３一
                p5 = str(brd.piece_at(sg.B2))       # ２二
                if p1 == "s" and p2 == "k":
                    wk[2] = True                    # 左美濃
                    wksw  = True
                if p1 == "s" and p3 == "k":
                    wk[2] = True                    # 左美濃
                    wksw  = True
                if p1 == "s" and p4 == "k":
                    wk[2] = True                    # 左美濃
                    wksw  = True
                if p1 == "s" and p5 == "k":
                    wk[2] = True                    # 左美濃
                    wksw  = True
            if not wksw:
                p1 = str(brd.piece_at(sg.B1))       # １二
                p2 = str(brd.piece_at(sg.A1))       # １一
                if p1 == "l" and p2 == "k":
                    wk[3] = True                    # 穴熊
                    wksw  = True
            if not wksw:
                p1 = str(brd.piece_at(sg.B9))       # ９二
                p2 = str(brd.piece_at(sg.A9))       # ９一
                if p1 == "l" and p2 == "k":
                    wk[3] = True                    # 穴熊
                    wksw  = True
            if not wksw:
                p1 = str(brd.piece_at(sg.B2))       # ２二
                p2 = str(brd.piece_at(sg.A2))       # ２一
                if p1 == "s" and p2 == "k":
                    wk[4] = True                    # ミレニアム
                    wksw  = True
            if not wksw:
                p1 = str(brd.piece_at(sg.B8))       # ８二
                p2 = str(brd.piece_at(sg.A8))       # ８一
                if p1 == "s" and p2 == "k":
                    wk[4] = True                    # ミレニアム
                    wksw  = True
            if not wksw:
                p1 = str(brd.piece_at(sg.A3))       # ３一
                p2 = str(brd.piece_at(sg.B4))       # ４二
                p3 = str(brd.piece_at(sg.B3))       # ３二
                if p1 == "g" and p2 == "s" and p3 == "k":
                    wk[5] = True                    # elmo
                    wksw  = True
            if not wksw:
                p1 = str(brd.piece_at(sg.A7))       # ７一
                p2 = str(brd.piece_at(sg.B6))       # ６二
                p3 = str(brd.piece_at(sg.B7))       # ７二
                if p1 == "g" and p2 == "s" and p3 == "k":
                    wk[5] = True                    # elmo
                    wksw  = True

    # 先手戦型
    esw = False
    if bs[0]:                                       # 角交換が入っている
        if not bssw and not wssw:                   # 他に戦型が決まっていない
            tagstr += senkei[0] + ","               # 角換わり固定
            esw     = True
        else:
            for i, wsw in enumerate(bs[1:]):
                if wsw:
                    if i > 4:                       # 振り飛車なら
                        tagstr += "角交換" + senkei[i + 1] + ","
                    else:
                        tagstr += senkei[i + 1] + ","
                    esw = True
                    break
    else:
        for i, wsw in enumerate(bs[1:]):
            if wsw:
                tagstr += senkei[i + 1] + ","
                esw     = True
                break
    if not esw:
        tagstr += "力戦,"

    # 後手戦型
    esw = False
    if ws[0]:                                       # 角交換が入っている
        if not bssw and not wssw:                   # 他に戦型が決まっていない
            tagstr += senkei[0] + ","               # 角換わり固定
            esw     = True
        else:
            for i, wsw in enumerate(ws[1:]):
                if wsw:
                    if i > 4:                       # 振り飛車なら
                        tagstr += "角交換" + senkei[i + 1] + ","
                    else:
                        tagstr += senkei[i + 1] + ","
                    esw = True
                    break
    else:
        for i, wsw in enumerate(ws[1:]):
            if wsw:
                tagstr += senkei[i + 1] + ","
                esw     = True
                break
    if not esw:
        tagstr += "力戦,"

    # 先手囲い
    esw = False
    for i, wsw in enumerate(bk):
        if wsw:
            tagstr += kakoi[i] + ","
            esw     = True
            break
    if not esw:
        tagstr += "その他,"

    # 後手囲い
    esw = False
    for i, wsw in enumerate(wk):
        if wsw:
            tagstr += kakoi[i] + ","
            esw     = True
            break
    if not esw:
        tagstr += "その他,"

    return tagstr


# CSA形式の棋譜ファイルの内容を渡し、戦型判別文字列を返す

def tag_str(csastr):

    kif = csa.Parser.parse_str(csastr)[0]
    return ans_senkei(kif)

# CSA形式の棋譜を読み込み、戦型判定文字列を返す

def tag_file(fname):

    with open(fname, "r", encoding="utf-8") as in_f:
        csastr = in_f.read()
    return tag_str(csastr)

# KIF形式の棋譜ファイルの内容を渡し、戦型判別文字列を返す

def tag_str_kif(kifstr):

    kif2 = kif.Parser.parse_str(kifstr)[0]
    return ans_senkei(kif2)

# KIF形式の棋譜を読み込み、戦型判定文字列を返す

def tag_file_kif(fname):

    with open(fname, "r", encoding="shift_jis") as in_f:
        kifstr = in_f.read()
    return tag_str_kif(kifstr)
