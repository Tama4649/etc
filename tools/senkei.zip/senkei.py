#
# CSA形式の棋譜から戦型、囲いを分類する
#

import shogi     as sg
import shogi.CSA as csa

senkei = [
    "角換わり", "矢倉", "横歩取り", "相掛かり", "中飛車", "四間飛車", "三間飛車",
    "向かい飛車", "右四間飛車", "袖飛車", "ダイレクト向かい飛車"
]
kakoi  = [
    "矢倉", "雁木", "美濃", "高美濃", "銀冠", "穴熊", "ミレニアム", "elmo"
]

# CSA形式の棋譜を読み込み、戦型判定文字列を返す
def tagging(fname):

    tagstr = ""
    brd    = sg.Board()
    kif    = csa.Parser.parse_file(fname)[0]
    bs     = [False, False, False, False, False, False, False, False, False, False, False]
    bk     = [False, False, False, False, False, False, False, False]
    ws     = [False, False, False, False, False, False, False, False, False, False, False]
    wk     = [False, False, False, False, False, False, False, False]

    for i, moves in enumerate(kif['moves']):

        if i > 29:                                  # 30手目までで判断
            break

        bpos = moves[:2]                            # 動かす前の座標
        apos = moves[2:4]                           # 動かした後の座標

        if bpos[0].isdecimal():                     # 駒移動なら
            bp = str(brd.piece_at(sg.SQUARES[sg.SQUARE_NAMES.index(bpos)]))
            ap = str(brd.piece_at(sg.SQUARES[sg.SQUARE_NAMES.index(apos)]))
            if brd.turn == 0:                       # 先手番なら
                if not (True in bs[1:]):            # 戦型が決まっていなければ
                    if bp == "B" and ap == "b":
                        bs[0] = True                # 角換わり
                        ws[0] = True                # 角換わり
                    if moves == "2h8h":
                        if bs[0]:
                            bs[10] = True           # ダイレクト向かい飛車
                            bs[0]  = False          # （ＤＭには角換わりの意味が含まれているため）
                            ws[0]  = False          # （ＤＭには角換わりの意味が含まれているため）
                        else:
                            bs[7]  = True           # 普通の向かい飛車
                    elif moves == "2h7h":
                        bs[6]  = True               # 三間飛車
                    elif moves == "2h6h":
                        bs[5]  = True               # 四間飛車
                    elif moves == "2h5h":
                        bs[4]  = True               # 中飛車
                    elif moves == "2h4h":
                        bs[8]  = True               # 右四間飛車
                    #elif moves == "2h3h":
                    #    bs[9]  = True               # 袖飛車
                    elif moves == "2d3d":
                        if bp == "R" and ap == "p" and not bs[0]:
                            bs[2] = True            # 横歩取り
                            ws[2] = True            # 横歩取り
                    p1 = str(brd.piece_at(sg.H7))   # ７八
                    p2 = str(brd.piece_at(sg.B3))   # ３二
                    p3 = str(brd.piece_at(sg.E2))   # ２五
                    p4 = str(brd.piece_at(sg.E8))   # ８五
                    if p1 == "G" and p2 == "g" and p3 == "P" and p4 == "p" and not bs[0]:
                        bs[3]  = True               # 相掛かり
                        ws[3]  = True               # 相掛かり
            else:                                   # 後手番なら
                if not (True in ws[1:]):            # 戦型が決まっていなければ
                    if bp == "b" and ap == "B":
                        ws[0] = True                # 角換わり
                        bs[0] = True                # 角換わり
                    if moves == "8b2b":
                        if ws[0]:
                            ws[10] = True           # ダイレクト向かい飛車
                            ws[0]  = False          # （ＤＭには角換わりの意味が含まれているため）
                            bs[0]  = False          # （ＤＭには角換わりの意味が含まれているため）
                        else:
                            ws[7]  = True           # 普通の向かい飛車
                    elif moves == "8b3b":
                        ws[6]  = True               # 三間飛車
                    elif moves == "8b4b":
                        ws[5]  = True               # 四間飛車
                    elif moves == "8b5b":
                        ws[4]  = True               # 中飛車
                    elif moves == "8b6b":
                        ws[8]  = True               # 右四間飛車
                    #elif moves == "8b7b":
                    #    ws[9]  = True               # 袖飛車
                    elif moves == "8f7f":
                        if bp == "r" and ap == "P" and not ws[0]:
                            ws[2] = True            # 横歩取り
                            bs[2] = True            # 横歩取り
                    p1 = str(brd.piece_at(sg.H7))   # ７八
                    p2 = str(brd.piece_at(sg.B3))   # ３二
                    p3 = str(brd.piece_at(sg.E2))   # ２五
                    p4 = str(brd.piece_at(sg.E8))   # ８五
                    if p1 == "G" and p2 == "g" and p3 == "P" and p4 == "p" and not ws[0]:
                        ws[3]  = True               # 相掛かり
                        bs[3]  = True               # 相掛かり

        brd.push(sg.Move.from_usi(moves))           # 1手指す

        if brd.turn == 1:                           # 先手番なら（指した後なので反転して判別）
            if not (True in bk):                    # 囲いが決まっていなければ
                p1 = str(brd.piece_at(sg.H7))       # ７八
                p2 = str(brd.piece_at(sg.G7))       # ７七
                if not bs[0] and p1 == "G" and p2 == "S":
                    if not (True in bs[4:]):        # 振られてなければ
                        bk[0] = True                # 矢倉
                        bs[1] = True                # 矢倉
                p1 = str(brd.piece_at(sg.H7))       # ７八
                p2 = str(brd.piece_at(sg.G6))       # ６七
                if p1 == "G" and p2 == "S":
                    if not (True in bs[4:]):        # 振られてなければ
                        bk[1] = True                # 雁木
                p1 = str(brd.piece_at(sg.H3))       # ３八
                p2 = str(brd.piece_at(sg.H4))       # ４八
                p3 = str(brd.piece_at(sg.I4))       # ４九
                p4 = str(brd.piece_at(sg.I3))       # ３九
                p5 = str(brd.piece_at(sg.H2))       # ２八
                if p1 == "S" and p2 == "K":
                    bk[2] = True                    # 美濃
                if p1 == "S" and p3 == "K":
                    bk[2] = True                    # 美濃
                if p1 == "S" and p4 == "K":
                    bk[2] = True                    # 美濃
                if p1 == "S" and p5 == "K":
                    bk[2] = True                    # 美濃
                p1 = str(brd.piece_at(sg.H7))       # ７八
                p2 = str(brd.piece_at(sg.H6))       # ６八
                p3 = str(brd.piece_at(sg.I6))       # ６九
                p4 = str(brd.piece_at(sg.I7))       # ７九
                p5 = str(brd.piece_at(sg.H8))       # ８八
                if p1 == "S" and p2 == "K":
                    bk[2] = True                    # 左美濃
                if p1 == "S" and p3 == "K":
                    bk[2] = True                    # 左美濃
                if p1 == "S" and p4 == "K":
                    bk[2] = True                    # 左美濃
                if p1 == "S" and p5 == "K":
                    bk[2] = True                    # 左美濃
                p1 = str(brd.piece_at(sg.H3))       # ３八
                p2 = str(brd.piece_at(sg.G4))       # ４七
                p3 = str(brd.piece_at(sg.H4))       # ４八
                p4 = str(brd.piece_at(sg.I4))       # ４九
                p5 = str(brd.piece_at(sg.I3))       # ３九
                p6 = str(brd.piece_at(sg.H2))       # ２八
                if p1 == "S" and p2 == "G" and p3 == "K":
                    bk[3] = True                    # 高美濃
                if p1 == "S" and p2 == "G" and p4 == "K":
                    bk[3] = True                    # 高美濃
                if p1 == "S" and p2 == "G" and p5 == "K":
                    bk[3] = True                    # 高美濃
                if p1 == "S" and p2 == "G" and p6 == "K":
                    bk[3] = True                    # 高美濃
                p1 = str(brd.piece_at(sg.H7))       # ７八
                p2 = str(brd.piece_at(sg.G6))       # ６七
                p3 = str(brd.piece_at(sg.H6))       # ６八
                p4 = str(brd.piece_at(sg.I6))       # ６九
                p5 = str(brd.piece_at(sg.I7))       # ７九
                p6 = str(brd.piece_at(sg.H8))       # ８八
                if p1 == "S" and p2 == "G" and p3 == "K":
                    bk[3] = True                    # 左高美濃
                if p1 == "S" and p2 == "G" and p4 == "K":
                    bk[3] = True                    # 左高美濃
                if p1 == "S" and p2 == "G" and p5 == "K":
                    bk[3] = True                    # 左高美濃
                if p1 == "S" and p2 == "G" and p6 == "K":
                    bk[3] = True                    # 左高美濃
                p1 = str(brd.piece_at(sg.H9))       # ９八
                p2 = str(brd.piece_at(sg.I9))       # ９九
                if p1 == "L" and p2 == "K":
                    bk[5] = True                    # 穴熊
                p1 = str(brd.piece_at(sg.H1))       # １八
                p2 = str(brd.piece_at(sg.I1))       # １九
                if p1 == "L" and p2 == "K":
                    bk[5] = True                    # 穴熊
                p1 = str(brd.piece_at(sg.H8))       # ８八
                p2 = str(brd.piece_at(sg.I8))       # ８九
                if p1 == "S" and p2 == "K":
                    bk[6] = True                    # ミレニアム
                p1 = str(brd.piece_at(sg.H2))       # ２八
                p2 = str(brd.piece_at(sg.I2))       # ２九
                if p1 == "S" and p2 == "K":
                    bk[6] = True                    # ミレニアム
                p1 = str(brd.piece_at(sg.I7))       # ７九
                p2 = str(brd.piece_at(sg.H6))       # ６八
                p3 = str(brd.piece_at(sg.H7))       # ７八
                if p1 == "G" and p2 == "S" and p3 == "K":
                    bk[7] = True                    # elmo
                p1 = str(brd.piece_at(sg.I3))       # ３九
                p2 = str(brd.piece_at(sg.H4))       # ４八
                p3 = str(brd.piece_at(sg.H3))       # ３八
                if p1 == "G" and p2 == "S" and p3 == "K":
                    bk[7] = True                    # elmo
        else:
            if not (True in wk):                    # 囲いが決まっていなければ
                p1 = str(brd.piece_at(sg.B3))
                p2 = str(brd.piece_at(sg.C3))
                if not ws[0] and p1 == "g" and p2 == "s":
                    if not (True in ws[4:]):        # 振られてなければ
                        wk[0] = True                # 矢倉
                        ws[1] = True                # 矢倉
                p1 = str(brd.piece_at(sg.B3))
                p2 = str(brd.piece_at(sg.C4))
                if p1 == "g" and p2 == "s":
                    if not (True in ws[4:]):        # 振られてなければ
                        wk[1] = True                # 雁木
                p1 = str(brd.piece_at(sg.B7))       # ７二
                p2 = str(brd.piece_at(sg.B6))       # ６二
                p3 = str(brd.piece_at(sg.A6))       # ６一
                p4 = str(brd.piece_at(sg.A7))       # ７一
                p5 = str(brd.piece_at(sg.B8))       # ８二
                if p1 == "s" and p2 == "k":
                    wk[2] = True                    # 美濃
                if p1 == "s" and p3 == "k":
                    wk[2] = True                    # 美濃
                if p1 == "s" and p4 == "k":
                    wk[2] = True                    # 美濃
                if p1 == "s" and p5 == "k":
                    wk[2] = True                    # 美濃
                p1 = str(brd.piece_at(sg.B3))       # ３二
                p2 = str(brd.piece_at(sg.B4))       # ４二
                p3 = str(brd.piece_at(sg.A4))       # ４一
                p4 = str(brd.piece_at(sg.A3))       # ３一
                p5 = str(brd.piece_at(sg.B2))       # ２二
                if p1 == "s" and p2 == "k":
                    wk[2] = True                    # 左美濃
                if p1 == "s" and p3 == "k":
                    wk[2] = True                    # 左美濃
                if p1 == "s" and p4 == "k":
                    wk[2] = True                    # 左美濃
                if p1 == "s" and p5 == "k":
                    wk[2] = True                    # 左美濃
                p1 = str(brd.piece_at(sg.B7))       # ７二
                p2 = str(brd.piece_at(sg.C6))       # ６三
                p3 = str(brd.piece_at(sg.B6))       # ６二
                p4 = str(brd.piece_at(sg.A6))       # ６一
                p5 = str(brd.piece_at(sg.A7))       # ７一
                p6 = str(brd.piece_at(sg.B8))       # ８二
                if p1 == "s" and p2 == "g" and p3 == "k":
                    wk[3] = True                    # 高美濃
                if p1 == "s" and p2 == "g" and p4 == "k":
                    wk[3] = True                    # 高美濃
                if p1 == "s" and p2 == "g" and p5 == "k":
                    wk[3] = True                    # 高美濃
                if p1 == "s" and p2 == "g" and p6 == "k":
                    wk[3] = True                    # 高美濃
                p1 = str(brd.piece_at(sg.B3))       # ３二
                p2 = str(brd.piece_at(sg.C4))       # ４三
                p3 = str(brd.piece_at(sg.B4))       # ４二
                p4 = str(brd.piece_at(sg.A4))       # ４一
                p5 = str(brd.piece_at(sg.A3))       # ３一
                p6 = str(brd.piece_at(sg.B2))       # ２二
                if p1 == "s" and p2 == "gk" and p3 == "k":
                    wk[3] = True                    # 左高美濃
                if p1 == "s" and p2 == "gk" and p4 == "k":
                    wk[3] = True                    # 左高美濃
                if p1 == "s" and p2 == "gk" and p5 == "k":
                    wk[3] = True                    # 左高美濃
                if p1 == "s" and p2 == "gk" and p6 == "k":
                    wk[3] = True                    # 左高美濃
                p1 = str(brd.piece_at(sg.B1))       # １二
                p2 = str(brd.piece_at(sg.A1))       # １一
                if p1 == "l" and p2 == "k":
                    wk[5] = True                    # 穴熊
                p1 = str(brd.piece_at(sg.B9))       # ９二
                p2 = str(brd.piece_at(sg.A9))       # ９一
                if p1 == "l" and p2 == "k":
                    wk[5] = True                    # 穴熊
                p1 = str(brd.piece_at(sg.B2))       # ２二
                p2 = str(brd.piece_at(sg.A2))       # ２一
                if p1 == "s" and p2 == "k":
                    wk[6] = True                    # ミレニアム
                p1 = str(brd.piece_at(sg.B8))       # ８二
                p2 = str(brd.piece_at(sg.A8))       # ８一
                if p1 == "s" and p2 == "k":
                    wk[6] = True                    # ミレニアム
                p1 = str(brd.piece_at(sg.A3))       # ３一
                p2 = str(brd.piece_at(sg.B4))       # ４二
                p3 = str(brd.piece_at(sg.B3))       # ３二
                if p1 == "g" and p2 == "s" and p3 == "k":
                    wk[7] = True                    # elmo
                p1 = str(brd.piece_at(sg.A7))       # ７一
                p2 = str(brd.piece_at(sg.B6))       # ６二
                p3 = str(brd.piece_at(sg.B7))       # ７二
                if p1 == "g" and p2 == "s" and p3 == "k":
                    wk[7] = True                    # elmo

    esw = False
    for i, wsw in enumerate(bs):
        if wsw:
            tagstr += senkei[i] + ","
            esw     = True
            break
    if not esw:
        tagstr += "力戦,"
    esw = False
    for i, wsw in enumerate(ws):
        if wsw:
            tagstr += senkei[i] + ","
            esw     = True
            break
    if not esw:
        tagstr += "力戦,"
    esw = False
    for i, wsw in enumerate(bk):
        if wsw:
            tagstr += kakoi[i] + ","
            esw     = True
            break
    if not esw:
        tagstr += "その他,"
    esw = False
    for i, wsw in enumerate(wk):
        if wsw:
            tagstr += kakoi[i] + ","
            esw     = True
            break
    if not esw:
        tagstr += "その他,"

    return tagstr
